#include "Stitch.h"

#include <iostream>
#include <opencv2/imgcodecs.hpp>

using namespace std;
using namespace cv;

int main()
{
	struct shift
	{
		double shift_r;
		double shift_c;
	};
	core::Stitch s;
	s.calculate_stitch_shifts_lr();
/*
	Mat up = imread("H:\\Data\\whole_lamel_data_5\\img_0_20.jpeg");
	Mat down = imread("H:\\Data\\whole_lamel_data_5\\img_1_66.jpeg");


    core::Stitch s;
	std::cout << s.stitch_ud(up,down).shift_c << endl;*/
}


//int main(){
	// Init Params

//	Mat image_down, image_up;
//	int cc_new, cc_direction;
//	vector<int> best_col_for_stitch(end_row - start_row, 0);
//	array<double, end_col - start_col> color_ratio_array;
//	shift stitch_result;
//	
//
//	double process_time = 0;
//	map<int, int> number_of_cols;
//	int n_row;
//	n_row = get_number_of_cols(data_dir, dataset_name, image_ext, number_of_cols);
//	clock_t tStart = clock();
//	// Start Stitching ...
//	cout << "Stitching ........" << endl;
//	Mat shift_row_array = Mat::zeros(end_row - start_row + 1, end_col - start_col + 1, CV_64FC1);
//	Mat shift_col_array = Mat::zeros(end_row - start_row + 1, end_col - start_col + 1, CV_64FC1);
//	tuple<int, int> range_r, range_c;
//	bool is_blank;
//	int last_thread_id;
//	setUseOptimized(true);
//
//	array<thread, number_of_threads> stich_thread_array;
//
//	for (int rr = start_row; rr <= end_row; rr++){
//		//max_color_area_ratio = -1.0;
//		color_ratio_array.fill(0);
//		for (int cc = start_col; cc < end_col; cc+= number_of_threads){
///*
//			//tt = clock();
//
//			// Column Number Correction
//
//
//			cout << clock() - tt << " Time" << endl;
//			tt = clock();
//
//			std::cout << "Stitch Time: " << clock() - stitch_time << endl << "######################################" << endl;
//*/
//			if (cc + number_of_threads < end_col) last_thread_id = cc + number_of_threads;
//			else last_thread_id = end_col;
//
//			for (int th = cc; th < last_thread_id; th++){
//				stich_thread_array[th%number_of_threads] = thread{ stitch_thread_lr, start_row, end_row, rr, start_col, end_col, th,
//					std::ref(shift_row_array), std::ref(shift_col_array), std::ref(number_of_cols), &color_ratio_array[th-start_col]};
//			}
//			for (int th = cc; th < last_thread_id; th++){
//				stich_thread_array[th%number_of_threads].join();
//			}
//		}
//		best_col_for_stitch[rr - start_row] = distance(color_ratio_array.begin(),
//			max_element(color_ratio_array.begin(), color_ratio_array.end())) + start_col;
//	}
//	std::cout << "Best Col For Stitch" << endl;
//	print_vector(best_col_for_stitch);
//	std::cout << "Whole Lamel Stitching Time: " << clock() - tStart << endl;
//
//
//	/*
//	# Shift Array Correction : Rows
//	for rr in range(end_row - start_row + 1) :
//		shift_row_array[rr, 1:][shift_row_array[rr, 1:] == -1000] = np.median(
//		shift_row_array[rr, 1:][shift_row_array[rr, 1:] != -1000])
//		shift_col_array[rr, 1:][shift_col_array[rr, 1:] == -1000] = np.median(
//		shift_col_array[rr, 1:][shift_col_array[rr, 1:] != -1000])
//	*/
//
//	for (int rr = start_row; rr < end_row; rr += number_of_threads){
//		
//		if (rr + number_of_threads < end_row) last_thread_id = rr + number_of_threads;
//		else last_thread_id = end_row;
//
//		for (int th = rr; th < last_thread_id; th++){
//			stich_thread_array[th%number_of_threads] = thread{ stitch_thread_ud, start_row, th, start_col,
//				std::ref(shift_row_array), std::ref(shift_col_array), std::ref(number_of_cols), best_col_for_stitch[th - start_row] };
//		}
//		for (int th = rr; th < last_thread_id; th++){
//			stich_thread_array[th%number_of_threads].join();
//		}
//	}
//
//	std::cout << "Whole Lamel Stitching Time: " << clock() - tStart << endl;
//
//	FileStorage file_r("row_shifts.xml", FileStorage::WRITE);
//	file_r << "rowShifts" << shift_row_array;
//
//	FileStorage file_c("col_shifts.xml", FileStorage::WRITE);
//	file_c << "colShifts" << shift_col_array;
//
//
//	// Converting to 2D-Array
//	uchar **shift_row_array_cpp = new uchar*[shift_row_array.rows];
//	for (int i = 0; i<shift_row_array.rows; ++i)
//		shift_row_array_cpp[i] = new uchar[shift_row_array.cols];
//
//	for (int i = 0; i<shift_row_array.rows; ++i)
//		shift_row_array_cpp[i] = shift_row_array.ptr<uchar>(i);
//
//
//	uchar **shift_col_array_cpp = new uchar*[shift_col_array.rows];
//	for (int i = 0; i<shift_col_array.rows; ++i)
//		shift_col_array_cpp[i] = new uchar[shift_col_array.cols];
//
//	for (int i = 0; i<shift_col_array.rows; ++i)
//		shift_col_array_cpp[i] = shift_col_array.ptr<uchar>(i);
//
//
//	_getch();
//	return 0;
//}

/*
Mat stitch_image(Mat image_left, Mat image_right, shift stitch_shift){
///////////////////////////////////////////////////////////////////
clock_t tStart = clock();
int is_smooth = 1;
long shift_r = stitch_shift.shift_r;
long shift_c = stitch_shift.shift_c;

int bottom_margin;
if (shift_r < 0){
bottom_margin = abs(shift_r) + max((long)image_left.rows, image_right.rows - abs(shift_r));
}
else{
bottom_margin = shift_r + max(image_left.rows - shift_r,(long)image_right.rows);
}

int right_margin = shift_c + max((long)image_right.cols, image_left.cols - shift_c);

Mat stitched_image = Mat(bottom_margin, right_margin, CV_8UC3, Scalar(0, 0, 0));
Mat stitched_label = Mat(stitched_image.rows, stitched_image.cols, CV_8UC3, Scalar(1, 1, 1));

Mat aux1_im = stitched_image.colRange(shift_c, shift_c + image_right.cols).rowRange(max((long)0, shift_r), max((long)0, shift_r) + image_right.rows);
Mat aux1_lb = stitched_label.colRange(shift_c, shift_c + image_right.cols).rowRange(max((long)0, shift_r), max((long)0, shift_r) + image_right.rows);

Mat zero_mat = Mat::zeros(image_right.rows, image_right.cols, CV_8UC3);
image_right.copyTo(aux1_im);
zero_mat.copyTo(aux1_lb);


Mat multiply_mat = Mat::zeros(image_left.rows, image_left.cols,CV_8UC3);
Mat aux2_lb, aux2_im;
if (shift_r >= 0){
aux2_lb = stitched_label.colRange(0, image_left.cols).rowRange(0, image_left.rows);
aux2_im = stitched_image.colRange(0, image_left.cols).rowRange(0, image_left.rows);
}
else{
aux2_lb = stitched_label.colRange(0, image_left.cols).rowRange(abs(shift_r), abs(shift_r) + image_left.rows);
aux2_im = stitched_image.colRange(0, image_left.cols).rowRange(abs(shift_r), abs(shift_r) + image_left.rows);
}

multiply(image_left, aux2_lb, multiply_mat);
add(aux2_im, multiply_mat, aux2_im);



////// smoothing in edges ...
if (is_smooth == 1){
int overlap_margin = 21;
vector<double> weights = linspace(0, 1, overlap_margin);
Mat M1, M2, aux3_stich_im, aux3_left_im, aux3_stich_im_scale, aux3_left_im_scale;

if (shift_r >= 0){
aux3_stich_im = stitched_image.rowRange(shift_r, min((long)image_left.rows, image_right.rows + shift_r)).colRange(shift_c, (shift_c + overlap_margin));
aux3_left_im = image_left.rowRange(shift_r, min((long)image_left.rows, image_right.rows + shift_r)).colRange(shift_c, (shift_c + overlap_margin));
M1 = Mat(min((long)image_left.rows, image_right.rows + shift_r) - shift_r, weights.size(), CV_32FC3, Scalar(0.0, 0.0, 0.0));
M2 = Mat(min((long)image_left.rows, image_right.rows + shift_r) - shift_r, weights.size(), CV_32FC3, Scalar(0.0, 0.0, 0.0));
}
else{
aux3_stich_im = stitched_image.rowRange(abs(shift_r), abs(shift_r) + min((long)image_left.rows, image_right.rows - abs(shift_r))).colRange(shift_c, (shift_c + overlap_margin));
aux3_left_im = image_left.rowRange(abs(shift_r), abs(shift_r) + min((long)image_left.rows, image_right.rows - abs(shift_r))).colRange(shift_c, (shift_c + overlap_margin));
M1 = Mat(min((long)image_left.rows, image_right.rows - abs(shift_r)), weights.size(), CV_32FC3, Scalar(0.0, 0.0, 0.0));
M2 = Mat(min((long)image_left.rows, image_right.rows - abs(shift_r)), weights.size(), CV_32FC3, Scalar(0.0, 0.0, 0.0));
}


aux3_stich_im_scale = Mat::zeros(M1.rows, M1.cols, CV_32FC3);
aux3_left_im_scale = Mat::zeros(M1.rows, M1.cols, CV_32FC3);

for (int ii = 0; ii < M1.cols; ii++){
for (int jj = 0; jj < M1.rows; jj++){
M1.at<Vec3f>(jj, ii) = Vec3f(weights.at(ii), weights.at(ii), weights.at(ii));
M2.at<Vec3f>(jj, ii) = Vec3f(1.0 - weights.at(ii), 1.0 - weights.at(ii), 1.0 - weights.at(ii));
}
}

Mat float_stitch = aux3_stich_im.clone();
float_stitch.convertTo(float_stitch, CV_32FC3);
Mat float_left = aux3_left_im.clone();
float_left.convertTo(float_left, CV_32FC3);

multiply(M1, float_stitch, aux3_stich_im_scale);
multiply(M2, float_left, aux3_left_im_scale);
add(aux3_stich_im_scale, aux3_left_im_scale, aux3_stich_im);


// Now Vertical
Mat M3, M4, aux4_stich_im, aux4_left_im, aux4_stich_im_scale, aux4_left_im_scale;
M3 = Mat(weights.size(), min((long)image_left.cols, image_right.cols + shift_c) - shift_c, CV_32FC3, Scalar(0.0, 0.0, 0.0));
M4 = Mat(weights.size(), min((long)image_left.cols, image_right.cols + shift_c) - shift_c, CV_32FC3, Scalar(0.0, 0.0, 0.0));

if (shift_r >= 0){
aux4_stich_im = stitched_image.rowRange(shift_r, shift_r + overlap_margin).colRange(shift_c, min((long)image_left.cols, image_right.cols + shift_c));
aux4_left_im = image_left.rowRange(shift_r, shift_r + overlap_margin).colRange(shift_c, min((long)image_left.cols, image_right.cols + shift_c));
}
else{
aux4_stich_im = stitched_image.rowRange(image_right.rows - overlap_margin, image_right.rows).colRange(shift_c, min((long)image_left.cols, image_right.cols + shift_c));
aux4_left_im = image_left.rowRange(min(image_right.rows - abs(shift_r), (long)image_left.rows) - overlap_margin, min(image_right.rows - abs(shift_r), (long)image_left.rows)).colRange(shift_c, min((long)image_left.cols, image_right.cols + shift_c));
}
aux4_stich_im_scale = Mat::zeros(M3.rows, M3.cols, CV_32FC3);
aux4_left_im_scale = Mat::zeros(M3.rows, M3.cols, CV_32FC3);

for (int ii = 0; ii < M3.cols; ii++){
for (int jj = 0; jj < M3.rows; jj++){
M3.at<Vec3f>(jj, ii) = Vec3f(weights.at(jj), weights.at(jj), weights.at(jj));
M4.at<Vec3f>(jj, ii) = Vec3f(1.0 - weights.at(jj), 1.0 - weights.at(jj), 1.0 - weights.at(jj));
}
}

if (shift_r >= 0 || (shift_r < 0 && abs(shift_r) + image_left.rows > image_right.rows)){
Mat float_stitch = aux4_stich_im.clone();
float_stitch.convertTo(float_stitch, CV_32FC3);
Mat float_left = aux4_left_im.clone();
float_left.convertTo(float_left, CV_32FC3);

multiply(M3, float_stitch, aux4_stich_im_scale);
multiply(M4, float_left, aux4_left_im_scale);
add(aux4_stich_im_scale, aux4_left_im_scale, aux4_stich_im);
}

}

printf("Stictching Time: %.2fs\n", (double)(clock() - tStart) / CLOCKS_PER_SEC);
return stitched_image;
}
*/

