#pragma once
#include <string>
#include <opencv2/core/mat.hpp>
#include <xtensor/xarray.hpp>

namespace core
{
    #define INVALID_VALUE -5000.0
    class Stitch
    {
    public:
		Stitch() = default;
		struct shift
		{
			double shift_r;
			double shift_c;

			shift() { shift_r = INVALID_VALUE; shift_c = INVALID_VALUE; }

            shift(double r, double c)
            {
				shift_r = r;
				shift_c = c;
            }
		};

		void calculate_stitch_shifts_lr();

		//void stitch_ud_thread(int start_row, int end_row,int start_col, int end_col);
        shift stitch_ud(cv::Mat& image_up, cv::Mat& image_down);
		shift stitch_lr(cv::Mat& image_left, cv::Mat& image_right);
        void stitch_thread_lr(int start_row, int end_row, int start_col, int end_col);

    private:
        struct blank_property
        {
			bool is_blank;
			double color_ratio;
        };
		shift stitch_shifts_lr[60][84];
		shift stitch_shifts_ud[60][84];

		blank_property is_image_blank(const cv::Mat& image);
		
		const int vertical_deviation = 2;
		int number_of_threads = 4;

		// init Parameters
        std::string data_dir = "H:\\Data";
        std::string dataset_name = "whole_lamel_data_5";
		std::string path_delim = "\\";
		std::string image_ext = "jpeg";
		std::string pref = "img_";

		// Stitching Parameters
		int split_ratio_lr = 6;
		int split_ratio_ud = 6;
		int maxHighCorrPoint_lr = 3;
		int maxHighCorrPoint_ud = 3;
		float acceptanceThresh_lr = 0.95;
		float acceptanceThresh_ud = 0.95;
		float lu_image_portion = 0.7;
		float expected_shift_r_ud = 1536, expected_shift_c_ud = 0,
			max_shift_c_threshold_ud = 2448, max_shift_r_threshold_ud = 308;
		float expected_shift_r_lr = 0.0, expected_shift_c_lr = 1836,
			max_shift_c_threshold_lr = 368, max_shift_r_threshold_lr = 308;
		int pyramid_scale = 1;
		double grey_std_thresh_ST = 11;
		double grey_std_thresh_BC = 5;
		int grey_std_threshold = 10;
		double area_threshold = 0.0001;
    };
}
