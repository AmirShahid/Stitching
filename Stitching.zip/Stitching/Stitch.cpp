#include "Stitch.h"
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <algorithm> 
#include <conio.h>
#include <time.h>
#include <string> 
#include <cmath> 
#include <boost/filesystem.hpp>
#include <stdio.h>
#include <cstdlib>
#include <math.h>
//#include <opencv2/>
#include <thread>

using namespace std;
using namespace core;
using namespace cv;


float round_n(float num, int dec)
{
	double m = (num < 0.0) ? -1.0 : 1.0;   // check if input is negative
	double pwr = pow(10, dec);
	return float(floor((double)num * m * pwr + 0.5) / pwr) * m;
}

template <typename T>
double calc_median(vector<double> shifts, T invalid_value = numeric_limits<double>::quiet_NaN)
{
	size_t size = shifts.size();
	vector<double> new_shifts;
	if (size == 0) return -2;  // Undefined, really.
	else
	{
		for (double v : shifts) if (v != invalid_value) new_shifts.push_back(v);

		if (new_shifts.empty()) return -1;

		sort(new_shifts.begin(), new_shifts.end());
		size = new_shifts.size();
		if (size % 2 == 0)
		{
			cout << (new_shifts[size / 2 - 1] + new_shifts[size / 2]) / 2 << endl;
			return (new_shifts[size / 2 - 1] + new_shifts[size / 2]) / 2;
		}
		else
		{
			return new_shifts[size / 2];
		}
	}
}


Stitch::blank_property Stitch::is_image_blank(const cv::Mat& image)
{
	int col_num = image.cols, row_num = image.rows;
	Mat BGR_layer[3];
	Mat absdiff_bg, absdiff_gr, absdiff_br, colorness_mat;
	split(image, BGR_layer);

	absdiff(BGR_layer[0], BGR_layer[1], absdiff_bg);
	absdiff(BGR_layer[1], BGR_layer[2], absdiff_gr);
	absdiff(BGR_layer[0], BGR_layer[2], absdiff_br);

	threshold(absdiff_bg, absdiff_bg, 2 * grey_std_threshold, 255.0, CV_THRESH_BINARY);
	threshold(absdiff_gr, absdiff_gr, 2 * grey_std_threshold, 255.0, CV_THRESH_BINARY);
	threshold(absdiff_br, absdiff_br, 2 * grey_std_threshold, 255.0, CV_THRESH_BINARY);

	bitwise_or(absdiff_bg, absdiff_br, colorness_mat);
	bitwise_or(absdiff_gr, colorness_mat, colorness_mat);

	const double color_ratio = sum(colorness_mat)[0] / (image.cols * image.rows) / 255.0;

    blank_property result;

    result.color_ratio = color_ratio;
	if (color_ratio < area_threshold)
	{
		result.is_blank = true;
		return result;
	};
	//std::cout << "COLORNESS_RATIO: " << color_ratio << endl;
	result.is_blank = false;
	return result;
}

Stitch::shift Stitch::stitch_ud(Mat& image_up, Mat& image_down) {

	shift stitch_shift;
	Mat image_cur_split, corrMatrix, image_up_gray, image_up_gray_cropped, image_down_gray;
	double max_value_corr, min_value_corr;
	int center_c;
	Point min_loc_corr, max_loc_corr, match_loc;
	
	cvtColor(image_up, image_up_gray, CV_BGR2GRAY);
	cvtColor(image_down, image_down_gray, CV_BGR2GRAY);
	int effective_y = (int)(image_up_gray.rows * lu_image_portion);
	image_up_gray(Rect(0, effective_y, image_up_gray.cols, (int)(image_up_gray.rows - effective_y))).copyTo(image_up_gray_cropped);

	// init list and parameters
    vector<double> shift_direction_r;
	vector<double> shift_direction_c;
	
	int step_r = (int)(image_down.rows / split_ratio_ud);
	int step_c = (int)(image_down.cols / split_ratio_ud);

	// Check Blankness

	blank_property blank_stat = is_image_blank(image_down(Rect(0, 0, image_down.cols, step_r)));
	if (blank_stat.is_blank)
	{
		//std::cout << stitch_shift.shift_r << "  " << stitch_shift.shift_c << "BLANK" << endl;
		return shift(INVALID_VALUE,INVALID_VALUE);
	}
	else
	{
		//image_up_gray_cropped.convertTo(image_up_gray_cropped, CV_32FC1);
		cv::Range range[2];
		for (int j = 0; j < split_ratio_ud; j++)
		{
			if (shift_direction_c.size() >= maxHighCorrPoint_ud) break;

			range[0] = Range(0, (long)step_r);
			range[1] = Range((long)(step_c * j), (long)(step_c * (j + 1)));
			image_cur_split = image_down_gray(range);
			//image_cur_split.convertTo(image_cur_split, CV_32FC1);

			matchTemplate(image_up_gray_cropped, image_cur_split, corrMatrix, TM_CCOEFF_NORMED);
			minMaxLoc(corrMatrix, &min_value_corr, &max_value_corr, &min_loc_corr, &max_loc_corr, Mat());
			//std::cout << "Max Corr Value: " << round_n(max_value_corr, 2) << endl;
			if(max_value_corr > acceptanceThresh_ud)
			{
				match_loc = max_loc_corr;
				match_loc.y += effective_y;
				center_c = (long)(image_down.cols / split_ratio_ud * j);
				if (((float) abs((match_loc.x - center_c) - expected_shift_c_ud)) > max_shift_c_threshold_ud ||
					((float) abs((match_loc.y - expected_shift_r_ud))) > max_shift_r_threshold_ud) continue;

				shift_direction_r.push_back((double)(match_loc.y));
				shift_direction_c.push_back((double)(match_loc.x - center_c));

			}

		}
		if (shift_direction_c.empty())
		{
			//std::cout << stitch_shift.shift_r << "  " << stitch_shift.shift_c << "NO DETECTTION" << endl;
			return shift(INVALID_VALUE,INVALID_VALUE);
		}
		else
		{
			stitch_shift.shift_c = (double)(calc_median(shift_direction_c, INVALID_VALUE) * pyramid_scale);
			stitch_shift.shift_r = (double)(calc_median(shift_direction_r, INVALID_VALUE) * pyramid_scale);
        
			//cout << "Row:  " << stitch_shift.shift_r << " Col:  " << stitch_shift.shift_c << endl;
			return stitch_shift;
		}
	}
}


Stitch::shift Stitch::stitch_lr(Mat& image_left, Mat& image_right) {

	clock_t ttt = clock();

	if (image_left.empty() || image_right.empty())
		return shift(INVALID_VALUE,INVALID_VALUE);

	//std::cout << "Stitching..." << endl;
	shift stitch_shift;
	double max_value_corr, min_value_corr;
	int center_r;
	Point min_loc_corr, max_loc_corr, match_loc;
	Mat image_left_gray, image_left_gray_cropped, image_right_gray, image_cur_split, corrMatrix;
	cvtColor(image_left, image_left_gray, CV_BGR2GRAY);
	cvtColor(image_right, image_right_gray, CV_BGR2GRAY);
	int effective_x = (int)(image_left_gray.cols * lu_image_portion);
	image_left_gray(Rect(effective_x, 0, (int)(image_left_gray.cols - effective_x), image_left_gray.rows)).copyTo(image_left_gray_cropped);

	// init list and parameters
	vector<double> shift_direction_r;
	vector<double> shift_direction_c;
	int temp_r = (int)(image_right_gray.rows / split_ratio_lr);
	int temp_c = (int)(image_right_gray.cols / split_ratio_lr);

	// Check Blankness
	//cout << "block_stitch_init_time: " << clock() - ttt << endl;
	//ttt = clock();

	blank_property blank_stat = is_image_blank(image_right(Rect(0, 0, temp_c, image_right.rows)));
	if (blank_stat.is_blank)
	{
		//std::cout << stitch_shift.shift_r << "  " << stitch_shift.shift_c << "BLANK" << endl;
		//cout << "block_stitch_isBlank_time: " << clock() - ttt << endl;
		return shift();
	}
	else
	{
		cv::Range range[2];
		//cout << "block_stitch_preStitch_time: " << clock() - ttt << endl;

		for (int i = 0; i < split_ratio_lr && shift_direction_c.size() < maxHighCorrPoint_lr; i++)
		{
			//ttt = clock();

			range[0] = Range((long)(temp_r * i), (long)(temp_r * (i + 1)));
			range[1] = Range(0, (long)(temp_c));
			image_cur_split = image_right_gray(range);
			//imshow("tmpl" + to_string(i), image_cur_split);
			//waitKey(0);

			matchTemplate(image_left_gray_cropped, image_cur_split, corrMatrix, TM_CCOEFF_NORMED);
			minMaxLoc(corrMatrix, &min_value_corr, &max_value_corr, &min_loc_corr, &max_loc_corr, Mat());
			//cout << "block_stitch_matchTemp_time: " << clock() - ttt << endl;
			if (max_value_corr > acceptanceThresh_lr)
			{
				//ttt = clock();
				match_loc = max_loc_corr;
				match_loc.x += effective_x;

				center_r = (long)(image_right_gray.rows / split_ratio_lr * i);

                //Check unexpected shift
				if (abs(match_loc.x - expected_shift_c_lr) > max_shift_c_threshold_lr || \
					abs((match_loc.y - center_r) - expected_shift_r_lr) > max_shift_r_threshold_lr) continue;
                
				shift_direction_r.push_back((double)(match_loc.y - center_r));
				shift_direction_c.push_back((double)(match_loc.x));
			}

		}
		if (shift_direction_c.empty())
		{
			//std::cout << stitch_shift.shift_r << "   " << stitch_shift.shift_c << "NO DETECTTION" << endl;
			return shift();
		}
		else
		{
			ttt = clock();
			stitch_shift.shift_c = (double)(calc_median(shift_direction_c, INVALID_VALUE) * pyramid_scale);
			stitch_shift.shift_r = (double)(calc_median(shift_direction_r, INVALID_VALUE) * pyramid_scale);

			//cout << "Row:  " <<  stitch_shift.shift_r << " Col:  " <<  stitch_shift.shift_c << endl;
			//cout << "block_stitch_calcMedian_time: " << clock() - ttt << endl;
			return stitch_shift;
		}
	}

}


void Stitch::stitch_thread_lr(int start_row, int end_row, int start_col, int end_col)
{
    for (auto i = start_row; i <= end_row ;i++)
    {
        for (auto j = start_col; j < end_col; j++)
        {
            auto image_left = imread(data_dir + path_delim + dataset_name + path_delim + pref + to_string(i) + "_" + to_string(j) + "." + image_ext, IMREAD_UNCHANGED);
            auto image_right = imread(data_dir + path_delim + dataset_name + path_delim + pref + to_string(i) + "_" + to_string(j+1) + "." + image_ext, IMREAD_UNCHANGED);
			stitch_shifts_lr[i][j] = stitch_lr(image_left, image_right);
        }
    }
}

void Stitch::calculate_stitch_shifts_lr()
{

	array<thread, 4> lr_threads;
    for (int i = 0; i < 60/4; i++)
    {
		for (int j = 0; j < 1; j++)
		{
			lr_threads[i] = thread{&Stitch::stitch_thread_lr,this,i, i, 0, 84};
		}
		for (int j = 0; j < 1; j++)
		{
			lr_threads[i].join();
		}
    }
    
    
}
 